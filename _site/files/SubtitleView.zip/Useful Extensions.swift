//
//  Useful Extensions.swift
//  Subtitle View
//
//  Created by Fitsyu on 3/17/17.
//  Copyright © 2017 fitsyu. All rights reserved.
//

import UIKit

extension UIView {
    static func loadFromNibNamed(nibNamed: String, bundle : Bundle? = nil) -> UIView? {
        return UINib(
            nibName: nibNamed,
            bundle: bundle
            ).instantiate(withOwner: nil, options: nil)[0] as? UIView
    }
}

extension UINavigationItem {
    
    /**
     * Add subtitle beneath the current title
     *
     *  - parameter subtitle: string to be used for subtitle.
     */
    func setSubtitle(_ subtitle: String) {
        
        let view = UIView.loadFromNibNamed(nibNamed: "SubtitleView") as! SubtitleView
        
        view.txTitle.text = self.title
        view.txSubTitle.text = subtitle
        
        
        self.titleView = view
        
    }
}
