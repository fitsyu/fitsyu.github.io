//
//  SubtitleView.swift
//  Subtitle View
//
//  Created by Fitsyu on 3/17/17.
//  Copyright © 2017 fitsyu. All rights reserved.
//

import UIKit

final class SubtitleView: UIView {
    
    // MARK: Outlets
    @IBOutlet weak var txTitle: UILabel!
    @IBOutlet weak var txSubTitle: UILabel!
    
}
